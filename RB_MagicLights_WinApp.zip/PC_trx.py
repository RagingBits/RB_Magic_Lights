
#! /usr/bin/env/ python
import os
import os.path
import sys
import socket
import io
import time
import argparse

# Instantiate the parser
argument_parser = argparse.ArgumentParser(description='PC_trx application to update configuration files remotely.')

ERROR__PATH_FILE = "ERR: File Path\n"
ERROR__CONNECTION = "ERR: Connection fail\n"
ERROR__HANDSHAKE = "ERR: Handshake fail\n"
ERROR__HOST_IP = "ERR: Host IP missing\n"
ERROR__INTERNAL_ERROR = "ERR: Internal error.\n"

IO_PORT = 16281
IO_BUFFER_SIZE = 256
IO_OK = "OK"
IO_OK_LEN = 2
IO_HANDSHAKE_SIZE = "F_SIZE:"
IO_HANDSHAKE_NAME = "F_NAME:"


soc_output = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


def send(host, port=IO_PORT, file_path=""):
    send_stage = 0
    last_stage = 0
    sending = True
    result = 0

    return_nessage = IO_OK

    if(os.path.isfile(file_path)):
        
        file = open(file_path, "rb")

        file_stats = os.stat(file.name)
        
        soc_output.connect((host, port))

        soc_output.settimeout(10)
         
        # Handshake file name.
        print("Handshake 1 send name.");
        result = soc_output.send(str.encode(IO_HANDSHAKE_NAME + os.path.basename(file_path)))

        if(0 != result):
            result = soc_output.recv(IO_OK_LEN)
         
            print("Res1: " + result.decode("utf-8"))
            # Handshake file size.
            if(result.decode("utf-8") == IO_OK):
                print("Handshake 2 send size.");
                result = soc_output.send(str.encode(IO_HANDSHAKE_SIZE + str(file_stats.st_size)))
            else:
                result = 0
                print("Handshake 1 fail.");
                return_nessage = ERROR__HANDSHAKE

        else:
            sending = False
            result = 0
            return_nessage = ERROR__CONNECTION


        if(0 != result):
            result = soc_output.recv(IO_OK_LEN)
            print("Res2: " + result.decode("utf-8"))
            if(result.decode("utf-8") == IO_OK):
                result = 1
            else:
                print("Handshake 2 fail.");
                result = 0
                return_nessage = ERROR__HANDSHAKE

        else:
            sending = False
            result = 0
            return_nessage = ERROR__CONNECTION


            
        # print("Res2: " + result.decode("utf-8"))

        # Send file.
        if(0 != result):

            while (sending == True):
                
                
                data_to_send = file.read(IO_BUFFER_SIZE)
                
                #print("Send: " + str(len(data_to_send)) + " bytes.")

                result = soc_output.send(data_to_send)
                #time.sleep(0.05)
                result = soc_output.recv(IO_OK_LEN)
   
                if (IO_OK == result.decode("utf-8")):
                    
                    if (len(data_to_send) < IO_BUFFER_SIZE):
                        result = 1 
                        sending = False
                        soc_output.close()
                       # print("End.")

                else:
                    sending = False
                    result = 0
                    return_nessage = ERROR__CONNECTION

    else:
        return_nessage = ERROR__PATH_FILE

    return return_nessage

def main():
    
    host_port = IO_PORT
    success = True
    sys.stdout.write("PC_TRX configuration update protocol. V1.0 (Sender only)\r\n")

    argument_parser = argparse.ArgumentParser()

    argument_parser.add_argument('-fp', required=True, help='A required valid path for the configuration file to be sent.')
    argument_parser.add_argument('-ip', required=True, help='A required valid IP of the host receiving the configuration file.')
    argument_parser.add_argument('-p', required=False, help='An optional alternative port to be used. Default port is ' + str(IO_PORT))

    args = argument_parser.parse_args()

    #print(args.p)


    if(success == True):
        #try:

        if(args.p is None):
            return_value = send(args.ip, IO_PORT, args.fp)
        else:
            port = int(args.p)
            return_value = send(args.ip, args.p, args.fp)

        sys.stdout.write(return_value);
        #except:
        #    sys.stdout.write(ERROR__INTERNAL_ERROR)
    


if __name__ == "__main__":
    main()