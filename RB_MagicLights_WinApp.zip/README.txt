Raging Bits Magic Lights

Installation and use:

1) Download and install python 3
	Get the installer from https://www.python.org/downloads/
	Start the installer and select "Add PATH", this will add the installation folder path to the windows PATH variable.
		This is needed so that python invocation can be done without absolute addressing.

2) Run "install pyserial.bat" to perform the "pyserial" installation.

The python scripts perform the conversion for LED Matrix studio outputs and data sending to the Magic Lights, can now run.
RB_MagicLights.exe will perform the call of these scripts seamlessly in a transparent way.

