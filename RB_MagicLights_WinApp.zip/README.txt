Raging Bits Magic Lights

Installation and use:

1) Download and install python 3
	Get the installer from https://www.python.org/downloads/
	Start the installer and select "Add python 3.x PATH", this will add the installation folder path to the windows PATH variable.
		This is needed so that python invocation can be done without absolute addressing.
	Proceed with python installation.

2) Run "install pyserial.bat" to perform the "pyserial" installation. 
	Alternatively, open a command prompt and execute "python -m pip install pyserial".

The python scripts perform the conversion for LED Matrix studio outputs and data sending to the Magic Lights, can now run.
RB_MagicLights.exe will perform the call of these scripts seamlessly in a transparent way.

Notes:
Windows and/or third parties defending tools (firewalls and antivirus) may prevent or sandbox the installation, without.
Follow https://github.com/RagingBits/RB_Magic_Lights/blob/main/Magic%20lights%20info%20document.pdf
for further instruction on how to get the Magic lights up and running.
